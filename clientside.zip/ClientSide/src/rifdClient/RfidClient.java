package rifdClient;

import com.phidget22.PhidgetException;

import com.phidget22.RFID;
import com.phidget22.RFIDTagEvent;
import com.phidget22.RFIDTagListener;
import com.phidget22.RFIDTagLostEvent;
import com.phidget22.RFIDTagLostListener;

import toServer.RfidData;
import toServer.RfidToServer;

import org.eclipse.paho.client.mqttv3.MqttException;

import com.google.gson.*;
import publisher.Publisher;


/**
 * 
 * @author Sam Robinson
 * 
 * this class can be seen as the main body of the program and is where all 
 * the other classes are called from. 
 * 
 * 
 *
 */

public class RfidClient {
	
    
    /*
     *calling all classes to be used in this class below 
     *
     *  RFID is a new object from the imported library phidget22 
     *  this is to be able to take input from the RFID scanner when the card 
     *  is scanned
     *  
     *  the publisher class can be found in the Client side project and the publisher package. 
     *  this is used to publish out the doorid once the the id comes back from the server
     *  
     *  Gson comes from the library com.google.gson this can be found in the imports
     *  this is used to convert strings and object to from json
     *  
     *  sensor to server is used to send json data to the server and can be found in the 
     *  client side project in the toServer package
     *  
     *  
     */

	
    RFID rfid = new RFID();
    //public static String sensorServerURL = "http://localhost:8081/ServerSide/SensorServerDB";
  
    RfidToServer SensorToServer = new RfidToServer(); 
    
    final Publisher publisher = new Publisher();
    
    RfidData RFIDScanned = 
    		new RfidData(0,"unknown", "unknown", "unknown", "unknown");
    
    Gson gson = new Gson();

    public static void main(String[] args) throws PhidgetException {
        new RfidClient(); 
    }
    
    /**
     * 
     * sends RFID data to the server and 
     * gets RFID back from the server to send out via the 
     * publisher to subcribers 
     * 
     * @param non
     * @throws PhidgetException
     */
    public RfidClient() throws PhidgetException {
    			//make a new RFID listener to get the RFID to send to the server
                rfid.addTagListener(new RFIDTagListener() {
                		// What to do when a tag is found
        			public void onTag(RFIDTagEvent e) {
        				//make a new string to get the id of the tag read
        				String tagRead = e.getTag();
        					
        					//this used to understand what the value of the tag that has been read is. 
        					//this is useful for debugging and knowing what tag is going to be sent to the server
        					System.out.println("DEBUG: Tag read: " + tagRead);
        					System.out.println("DEBUG: Sending new rfid value : " + tagRead);
        					
        					//this could be sued for the user to understand what tag has been read 
        					//if there was a front end
        					System.out.println("Tag name: " + tagRead +" "+ "read");
        					
        					int sensorname = 0;
        					try {
        						sensorname =  rfid.getDeviceSerialNumber();
        						
								System.out.println(rfid.getDeviceSerialNumber());
								
							} catch (PhidgetException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
        					//print out the has code and the source to understand where the tag has been scanned into
        					//this can be used to debug, if you want to know where you are scanning 
        					System.out.println("tag hash code: "+" "+ e.hashCode());
        					System.out.println("get source" +" "+ e.getSource());
        					
        					//set the sensorname to to the DeviceID as it is always going to be RFID RFID when a card is scanned in
        					//from the client
        					RFIDScanned.setSensorname(sensorname);
        					//set the sensor value to the tag read to be sent to the sever
        					RFIDScanned.setRFIDKeyValue(tagRead);
        					
        					RFIDScanned.setclientype("RFIDClient");
        					//RFIDScanned object to json string to send to server
        					String RFIDScannedJson = gson.toJson(RFIDScanned);
        					//debug print to understand what is being sent to server. this done so that we can see
        					//if we are sending the correct values 
        					System.out.println("sending data to server: "+ RFIDScannedJson);
        					
        					//make a string from the returned value from the server and send the json string to the server.
        					String resultfromserver = SensorToServer.sendToServer(RFIDScannedJson);
        					System.out.println("result from server: "+resultfromserver);
        					
        					
        					//convert json from server to sensordata object to get the door id
        					RFIDScanned = gson.fromJson(resultfromserver, RfidData.class);
        					//debug get the door id so we one understand if the door id is correct for the card a
        					//and two just know what the door id is, and three if the door has even come back form the server
        					System.out.println("\n"+ "Door id:"+ RFIDScanned.getdoorid());
        		            
        					//set the door to a stirng to be then passed to the start function to publish out to subcribing 
        					//doors
        					String doorid = RFIDScanned.getdoorid();
        					
        					
        					//if the result from the server is null or just and empty string it means 
        					//card id is not in the database and so the door is not opening.
        		            
        					//start pubishing to the subcribing doors if the result from the server contains the tag read.
        		            //this is to make sure that card has come back from the server
        					if(resultfromserver.contains(tagRead)) {
        						System.out.println(resultfromserver);
        						 try {
									publisher.publishMotor(doorid);
								} catch (MqttException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
        					}else {
        						try {
									publisher.publishFailed(RFIDScanned.getSensorname());
								} catch (MqttException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
        						
        					}
        			}
              });
                
                
             rfid.addTagLostListener(new RFIDTagLostListener() {
                		  // What to do when a tag is lost
        			public void onTagLost(RFIDTagLostEvent e) {
        				// optional print, used as debug here
        				System.out.println("DEBUG: Tag lost: " + e.getTag());
        			}
                });
                
                // Open and start detecting rfid cards
                rfid.open(0);  // wait 5 seconds for device to respond

                // attach to the sensor and start reading
            try {      	                                
                System.out.println("\n\nGathering data for 15 seconds\n\n");
                pause(60);
                rfid.close();
                System.out.println("\nClosed RFID Reader");
                //Thread.sleep(1500);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
    }  
    /**
     * 
     * @param secs
     * @return non
     */
    private void pause(int secs){
        try {
			Thread.sleep(secs*1000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    }
}




