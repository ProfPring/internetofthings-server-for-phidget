package utils;

public class utils {    
    public static void waitFor(int numSeconds) {
		// pauses for numSeconds
		try {
			Thread.sleep(numSeconds * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
    
}
