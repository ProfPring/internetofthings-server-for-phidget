package LockMover;

import com.phidget22.PhidgetException;
import com.phidget22.RCServo;
import com.phidget22.RCServoPositionChangeEvent;
import com.phidget22.RCServoPositionChangeListener;
import com.phidget22.RCServoTargetPositionReachedEvent;
import com.phidget22.RCServoTargetPositionReachedListener;
import com.phidget22.RCServoVelocityChangeEvent;
import com.phidget22.RCServoVelocityChangeListener;

/**
 * 
 * 
 *
 *this class is used to move the motor and print 
 *debug for where the motor has been moved and if the motor has been moved at all
 *
 *it is used to understand the speed and control the speed of the motor. the speed
 *of the motor is also the same.
 *
 *
 */


public class LockMover {

	/*
	 *  Singleton implementation to allow multiple callbacks to the code
	 */
	
	
		static RCServo servo = null;
		

		   public static RCServo getInstance() {
			  System.out.println("singleton constructor");
		      if(servo == null) {
		         servo = PhidgetMotorMover();
		      }
		      return servo;
		   }
		
		
		
		private static  RCServo PhidgetMotorMover() {
			// Create new instance of servo board and start listening for motor changes
			// This method should only be called once when first constructing a servo instance
			try {	
				System.out.println("Constructing MotorMover");
				servo = new RCServo();
				// optionally add listeners to moving.
				// Can remove if necessary
		        servo.addVelocityChangeListener(new RCServoVelocityChangeListener() {
					public void onVelocityChange(RCServoVelocityChangeEvent e) {
					
					}
		        });
		        

		        
		        //this is the event listen that will check if the motor has been moved
		        servo.addPositionChangeListener(new RCServoPositionChangeListener() {
					public void onPositionChange(RCServoPositionChangeEvent e) {
						
					}
		        });
		        //check if the target has been reached and print it out. this done to understand 
		        //if the motor has reached the pos you want to be moved to 
		        servo.addTargetPositionReachedListener(new RCServoTargetPositionReachedListener() {
					public void onTargetPositionReached(RCServoTargetPositionReachedEvent e) {
					}
		        });
		     

			// Start listening for motor interaction
				servo.open(2000);
			} catch (PhidgetException e) {
				e.printStackTrace();

			}
				//this is done to reset the motor to 0 each time. 
		        moveServoTo(0);
		        System.out.println("Motor initially positioned at: 0");
	        return servo;
		}               


		/***
		 * @return void
		 * @param motorPosition
		 */
		public static void moveServoTo(double motorPosition) {
	        try {
	        		// Get the servo that is available
	        		LockMover.getInstance();
	        		//set the max of the motor to prevent the door trying open greater than the wall
	        		//also the prevent the motor straining.
	        		servo.setMaxPosition(210.0);
				servo.setTargetPosition(motorPosition);
				servo.setEngaged(true);
			} catch (PhidgetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
	
	
}
