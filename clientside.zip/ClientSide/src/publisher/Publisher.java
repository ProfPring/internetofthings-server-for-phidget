package publisher;

import org.eclipse.paho.client.mqttv3.*;

/**
 * 
 * @author Sam Robinson
 * 
 * this class is used to publish out the door id to subcribing 
 * doors. 
 * 
 * 
 *
 */


public class Publisher {

	/*
	 *Broker_url sets up the url of the cloud server being used to publish out the 
	 *motor subcriber
	 *
	 *user id is used to make the name of the client and is just a stirng of numbers
	 * 
	 * MqttClient is making a new client 
	 * 
	 * 
	 */
	
	
	 //public static final String BROKER_URL = "tcp://iot.eclipse.org:1883";
    //public static final String BROKER_URL = "tcp://broker.mqttdashboard.com:1883";
    public static final String BROKER_URL = "tcp://test.mosquitto.org:1883";

    public static final String userid = "16040238"; 


    private MqttClient client;


    
    public Publisher() {

        try {
            client = new MqttClient(BROKER_URL, userid);
            	
          	  MqttConnectOptions options = new MqttConnectOptions();
                options.setCleanSession(false);
                options.setMaxInflight(1000);
                options.setAutomaticReconnect(true);
                //options.notifyAll();
                options.setWill(client.getTopic(userid + "/LWT"), "I'm gone :(".getBytes(), 0, false);
                try {
      			client.connect(options);
      			System.out.println("publisher ready!");
      		//publish out once so the door opens and closes once. 
      		} catch (MqttException e) {
      			// TODO Auto-generated catch block
      			e.printStackTrace();
      		}             
        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
        
    
    /**
     * 
     * @param DoorId
     * @throws MqttException
     */
    //publish out door id and make the top that is being published to the doorid 
    //the door is given in the Sensor client when the server sends the doorid stored in the database
    public void publishMotor(String DoorId) throws MqttException {
    	//the topic is what the subcriber is listening to 
        final MqttTopic MotorTopic = client.getTopic(DoorId+"/motor");
        //the message being sent to the door
        final String motor = "door opened from card scan" + "";
        //publish Mqtt
        MotorTopic.publish(new MqttMessage(motor.getBytes()));
        System.out.println("Published data. Topic: " + MotorTopic.getName() + "   Message: " + motor);
    }  
    /**
     * 
     * @param sensorname
     * @throws MqttException
     */
    public void publishFailed(int sensorname) throws MqttException {
    	//the topic is what the subcriber is listening to 
        final MqttTopic PhoneTopic = client.getTopic(sensorname+"/attempts");
        //the message being sent to the door
        final String message = "door failed to open door from card scan" + "";
        //publish Mqtt
        PhoneTopic.publish(new MqttMessage(message.getBytes()));
        System.out.println("Published data. Topic: " + PhoneTopic.getName() + "   Message: " + message);
    }  
}       


