package subscriber;


/**
 * @author Sam Robinson
 * 
 * MQTT client
 * 
 * 
 * this class is the subcriber for the motor. this class 
 * calls a callback which then moved the motor when this class gets the 
 * door id is it waiting for in this case it is 1
 * 
 * when called the methods in this class take no arguments as they not needed 
 * all this class does is listen for the doorid that it has been given which is done 
 * by the client when the publisher is passed the doorid
 * 
 * 
 */



import com.phidget22.* ;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import com.google.gson.*;
import subscriber.GetLockFromServer;

public class Subcriber {

	 	//public static final String BROKER_URL = "tcp://broker.mqttdashboard.com:1883";
	 	public static final String BROKER_URL = "tcp://test.mosquitto.org:1883";
	 	
	 	Gson gson = new Gson();
		doorData door = new doorData(0, "", "");
		GetLockFromServer doorlock = new GetLockFromServer();  
		
		/**
		 * this gets the motor seriel number from the motor
		 * @param none
		 * @return motorid
		 */
		private int id(){
			int motorid = 0;
			try {
				
				RCServo servo = null; 
				
				if(servo == null) {
					servo = LockMover.LockMover.getInstance();
				}
				motorid = servo.getDeviceSerialNumber();				
				System.out.println("motor id "+ motorid);
				door.setmotorid(motorid);
				
			} catch (PhidgetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return motorid; 
		}

		int motorid = id();
		
		String clientType = "subcriber";	
		
		/**
		 * 
		 * gets the motor id from the server
		 * 
		 * @return doorid
		 * @throws PhidgetException
		 */
		private String doorid() throws PhidgetException {
			String doorid="";
	    	door.setclientype(clientType);
			door.setmotorid(id());
			String doorJson = gson.toJson(door);
			
			String result = doorlock.sendToServer(doorJson);
			System.out.print(result);
			door = gson.fromJson(result, doorData.class);
			doorid = door.getdoorid();	
			
			System.out.println(doorid);
			
			return doorid;
		}
		
	    
		private MqttClient mqttClient;
		/**
		 * sets the subcriber client id and makes a new MQTT client
		 * 
		 * @throws PhidgetException
		 */
	    public Subcriber() throws PhidgetException {

	        try {
				String clientId = "doorlockSub1" + "-sub";	    
	        	
	            mqttClient = new MqttClient(BROKER_URL, clientId);

	        } catch (MqttException e) {
	            e.printStackTrace();
	            System.exit(1);
	        }
	    }
	    	   
	    /**
	     * starts the subcribering
	     * @throws PhidgetException
	     */
	    public void start() throws PhidgetException{
	        try {
	            mqttClient.setCallback(new MotorSubcribercallback());
	            mqttClient.connect();
	            MqttConnectOptions options = new MqttConnectOptions();
	            options.setAutomaticReconnect(true);
	            
	            // Name of topic for subscribing. 
	            // NB Only works when 3rd party is publishing to this topic
	            final String topic = doorid()+"/motor";
	            mqttClient.subscribe(topic);
	            //PhidgetSensorClients.MotorMoverClient.moveServoTo(180.0);
	            System.out.println("Subscriber is now listening to "+topic);
	            

	        } catch (MqttException e) {
	            e.printStackTrace();
	            System.exit(1);
	        }
	    }
	    public static void main(String... args) throws PhidgetException {
	        	final Subcriber subscriber = new Subcriber();
	        	subscriber.start();
	    }
	
}
