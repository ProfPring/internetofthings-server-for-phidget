package subscriber;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import com.phidget22.* ;

//import toServer.RfidToServer;


/**
 *
 * 
 * @author sam Robinson
 *
 *this class gets the lock information from the server.
 *
 *
 */

public class GetLockFromServer {

	 public static String sensorServerURL = "http://localhost:8081/ServerSide/ServerDatabaseHandler";
	 
	    public static void main(String[] args) {
	        new GetLockFromServer();
	    }
	    public String sendToServer(String DoorJson) throws PhidgetException{
	    
	    	
	        URL url;
	        HttpURLConnection conn;
	        BufferedReader rd;
	        // Replace invalid URL characters from json string
	        try {
	        	DoorJson = URLEncoder.encode(DoorJson, "UTF-8");
			} catch (UnsupportedEncodingException e1) {
				e1.printStackTrace();
			}
	        String fullURL = sensorServerURL + "?sensordata="+DoorJson;
	        System.out.println("Sending data to: "+fullURL);  // DEBUG confirmation message
	        String line;
	        String result = "";
	        try {
	           url = new URL(fullURL);
	           conn = (HttpURLConnection) url.openConnection();
	           conn.setRequestMethod("GET");
	           rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	           // Request response from server to enable URL to be opened
	           while ((line = rd.readLine()) != null) {
	              result += line;
	           }
	           rd.close();
	        } catch (Exception e) {
	           System.out.println("error");
	           e.printStackTrace();
	        }
	        return result;    	
	    }
	    	
}
