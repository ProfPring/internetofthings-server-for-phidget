package subscriber;

import org.eclipse.paho.client.mqttv3.*;

import utils.utils;

/**
 * 
 * @author Sam Robinson
 * @category call back class for motor mover
 * 
 * this class is used by the subcriber so move the motor 
 * and to get a print out of the mesaage and topic that has been sent 
 * 
 * this class has one method which takes two arguments of type 
 * String and MQTT message which are pass in when called. 
 * 
 * when the message arrived method is classed from this class it moves motor using 
 * the motor mover class. this method will also print out that the motor has been
 * moved to 180. this will then close the door by moving the motor again to 50.0 degrees
 * 
 * 
 * 
 *
 */

public class MotorSubcribercallback implements MqttCallback {
	public static final String userid = "1"; 

    @Override
    public void connectionLost(Throwable cause) {
        //This is called when the connection is lost. We could reconnect here.
    }

    @Override
    /**
     * moves the motor on the client side
     * and prints out message
     * 
     * @throws Exception
     * 
     */
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        System.out.println("Message arrived. Topic: " + topic + "  Message: " + message.toString());
        
        // Move motor to open, then shut after pausing
        LockMover.LockMover.moveServoTo(180.0);
        System.out.println("Waiting until motor at position 180");
        utils.waitFor(5);
        LockMover.LockMover.moveServoTo(1.0);
        utils.waitFor(2);
        
        if ((userid+"/LWT").equals(topic)) {
            System.err.println("Sensor gone!");
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
        //no-op
    }
}
