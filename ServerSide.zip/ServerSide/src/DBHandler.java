import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.*;

import java.io.*;
import java.sql.*;


/**
 * *@author Sam Robinson
 *
 *this class is the database handler for the server. this class sends and gets data to and from the client
 *this class executes SQL and gets result sets from the database
 *
 *
 */


/**
 * Servlet implementation class sensorToDB
 */
@WebServlet("/ServerDatabaseHandler")
public class DBHandler extends HttpServlet  {
	/*global varibles uses to store connection status, Gson object, 
	  STMT. these are uses through out muliple times.	
	*/
	private static final long serialVersionUID = 1L;
    Gson gson = new Gson();
	Connection conn = null;
	Statement stmt;
	
/**
 * 
 * @param servlet config
 * @return void
 */
  public void init(ServletConfig config) throws ServletException {
  // init method is run once at the start of the servlet loading
	  super.init(config);
	  System.out.println("Server database handler \n");	
	  System.out.println("Upload sensor data with http://localhost:8081/ServerSide/ServerDatabaseHandler?sensorname=somesensorname&sensorvalue=somesensorvalue");
	  System.out.println("View last sensor reading at  http://localhost:8081/ServerSide/ServerDatabaseHandler?getdata=true\n\n");
  } // init()

 /**
 *@param nothing 
 * @return void
 */
private void getConnection() {
	  // This will load the driver and establish a connection
		String user = "robinsos";
	    String password = "bRennast2";

	    //connection string to SQL server. do not change the port number.
	    String url = "jdbc:mysql://mudfoot.doc.stu.mmu.ac.uk:6306/"+user;

		// Load the database driver 
		try {  
				Class.forName("com.mysql.jdbc.Driver").newInstance();
	        } catch (Exception e) {
	            System.out.println(e);
	        }
			// get a connection with the user/pass
	        try {
	            conn = DriverManager.getConnection(url, user, password);
	            stmt = conn.createStatement();
	        } catch (SQLException se) {
	            System.out.println(se);
	            System.out.println("\nDid you alter the lines to set user/password in the sensor server code?");
	        }
  }

  private void closeConnection() {
		// get a connection with the user/pass
        try {
            conn.close();
        } catch (Exception e) {
            System.out.println(e);
        }
  
  }
  
  public void destroy() {
        try { // conn.close();  // should have no need to close connection
        	  // add anything extra to do when servlet closes
        } catch (Exception e) {
            System.out.println(e);
        }
  } // destroy()
  


public DBHandler() {
    super();
    // TODO Auto-generated constructor stub
}


/**
 * do get calls methods to proccees data for sending back data back to the client 
 * this done when doGet gets a json object from the client
 * 
 * 
 * @param HTTPServletRequest request, HttpServletResponse response
 * 
 * @throws ServletException, IOException
 * 
 * 
 * @return void
 * 
 **/
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setStatus(HttpServletResponse.SC_OK);
    // Declare a SensorData object to hold the incoming data
    RfidData RFIDdataSent = new RfidData(0, "unknown", "unknown", "unkown", "unkown");
	doorData door = new doorData(0, "", "");
    
		// Problem if sensordata parameter not sent, or is invalid json
    	String sensorJsonString = request.getParameter("sensordata");
    	
		if(sensorJsonString !=null) 
		{
			RFIDdataSent = gson.fromJson(sensorJsonString, RfidData.class);
			System.out.println("json from client: "+RFIDdataSent.toString());
			
			if (RFIDdataSent.getclientType().equals("RFIDClient") || RFIDdataSent.getclientType().equals("PhoneApp") ) {
				//store IsValid result is varible this mans it's only run once
				boolean IsValid = IsValid(RFIDdataSent);
				if(IsValid) {	
				//package data into josn to be sent back
				String resultJson = ResultToSendBack(RFIDdataSent, door, IsValid);
				
				updateLogTable(RFIDdataSent, IsValid);
				//send json back to client if the card is valid
				sentoClient(resultJson, response);
					
				}else{
					String resultJson = ResultToSendBack(RFIDdataSent, door, IsValid);
					sentoClient(resultJson, response);
					updateLogTable(RFIDdataSent, IsValid );
					System.out.println("result set was empty door not opening");
					
				}
				
			}else if(RFIDdataSent.getclientType().equals("subcriber")) {
				
				
				door = gson.fromJson(sensorJsonString, doorData.class); 
				String resultJson = ResultToSendBack(RFIDdataSent, door, true);
				
				sentoClient(resultJson, response);
				System.out.println("sending door ids to doors");
		}
		return;
	}		
}
/**
 * 
 * @param resultJson
 * @param response
 * @throws IOException
 */

public void sentoClient(String resultJson,  HttpServletResponse response) throws IOException {
	//print writer sends data back to client.
	PrintWriter responsePrintWriter = response.getWriter();
	responsePrintWriter.println(resultJson);
	responsePrintWriter.close();	
	
} 

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    // Post is same as Get, so pass on parameters and do same
    doGet(request, response);
}

/**
 * checks id card is valid  for phone and RFID client
 * 
 * 
 * @param RFIDdataSent
 * @return boolean
 * 
 */
private boolean IsValid(RfidData RFIDdataSent){
	ResultSet rs;
	
	if (RFIDdataSent.getclientType().equals("RFIDClient")) {
		String SelectData = 
				" Select * "
				+" from RFIDdataTable"
				+" where sensorvalue="+"'"+RFIDdataSent.getRFIDKeyValue()+"'" + " and sensorname="+ "'"+RFIDdataSent.getSensorname()+"'";
		try {
			getConnection();
			rs = stmt.executeQuery(SelectData);
			//if the result is empty return false
			if(rs.next() == false)
		     {
				
		    	 System.out.println("\n"+SelectData+" result set is empty ");
		    	 closeConnection();
		    	 return false;
		    	 //check if the sensor name is correct for the card id
		     }else if(rs.getInt("sensorname") == RFIDdataSent.getSensorname()){
		    	 closeConnection();
		    	 System.out.println(SelectData+ "DEBUG: resultset was not empty"+"\n");
		    	 return true;
		     }
			
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}else if( RFIDdataSent.getclientType().equals("PhoneApp")){
		String SelectData = 
				" Select * "
				+" from RFIDdataTable"
				+" where PhoneID="+"'"+RFIDdataSent.getPhoneID()+"'";
		try {
			getConnection();
			rs = stmt.executeQuery(SelectData);
			
			if(rs.next() == false)
		     {
		    	 System.out.println("\n"+SelectData+" result set is empty ");
		    	 closeConnection();
		    	 return false;
		     }else{
		    	 closeConnection();
		    	 System.out.println(SelectData+ "DEBUG: resultset was not empty"+"\n");
		    	 return true;
		     }
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
    return false;
     
}


/**
 *
 * @param RFIDdataSent, doorData
 * 
 * @return String
 * 
 * 
 **/
private String ResultToSendBack(RfidData RFIDdataSent, doorData doorData, boolean Valid){
	ResultSet rs;
	
	RfidData thisSensor = new RfidData(0, "unknown", "unknown", "unknown", "unknown");
	doorData thisdoor = new doorData(0, "", "");
	
	if (RFIDdataSent.getclientType().equals("RFIDClient") && Valid) {
	
	String SelectData = 
			" Select * "
			+" from RFIDdataTable"
			+" where sensorvalue="+"'"+RFIDdataSent.getRFIDKeyValue()+"'" + " and sensorname="+ "'"+RFIDdataSent.getSensorname()+"'";
	
	 try {
	 getConnection();
     rs = stmt.executeQuery(SelectData);
     	while(rs.next()) {   
     		//update this sensor to send to client with sensorvalue which is the key ID 
     		thisSensor.setRFIDKeyValue(rs.getString("sensorvalue"));
		   	thisSensor.setdoorid(rs.getString("doorid"));		
		   	thisSensor.setPhoneID(rs.getString("PhoneID") );
     	}
	 	}catch(SQLException ex) {
	 		System.out.print(ex.toString());
	 		System.out.print("error in Sending Result" + " look at SQL");
	 	}
     closeConnection();
     	
   
     String JsonSensorAndDoor = gson.toJson(thisSensor);
     
     System.out.println("json being sent back: "+ JsonSensorAndDoor);
     return JsonSensorAndDoor;
     
	}//if the card is not valid send back a json object with the RFID key value they scanned in. this could be filled in with any information
	//in the future for any new functionality 
	else if(RFIDdataSent.getclientType().equals("RFIDClient") && !Valid) {
		
		thisSensor.setSensorname(RFIDdataSent.getSensorname());
		String JsonSensorAndDoor = gson.toJson(thisSensor); 
	    System.out.println("json being sent back: "+ JsonSensorAndDoor);
	    return JsonSensorAndDoor; 
	     
	}
	else if(RFIDdataSent.getclientType().equals("PhoneApp") && Valid) {
		String SelectData = 
				" Select * "
				+" from RFIDdataTable"
				+" where PhoneID="+"'"+RFIDdataSent.getPhoneID()+"'";
		
		 try {
		 getConnection();
	     rs = stmt.executeQuery(SelectData);
	     	while(rs.next()) {   
	     		//only send back the door id and sensorname to the phone. 
	     		//the sensorname is used to subcribe to the attempts for this given door. 
	     		thisSensor.setdoorid(rs.getString("doorid"));
	     		thisSensor.setSensorname(rs.getInt("sensorname"));
	     	}
		 	}catch(SQLException ex) {
		 		System.out.print(ex.toString());
		 		System.out.print("error in Sending Result" + " look at SQL");
		 	}
	     closeConnection();
	     	
	   
	     String JsonSensorAndDoor = gson.toJson(thisSensor);
	     
	     System.out.println("json being sent back: "+ JsonSensorAndDoor);
	     return JsonSensorAndDoor;
	}//the subcriber is the door asking for its ID  
	if(RFIDdataSent.getclientType().equals("subcriber") && Valid) {
		String SelectDoorId = 
				" Select * "
				+" from DoorTable"
				+" where motorid= "+doorData.motorid;
		try {
		getConnection();
	     rs = stmt.executeQuery(SelectDoorId);
	     	while(rs.next()) {   
	     		thisdoor.setdoorid(rs.getString("doorid"));		 
	     	}
		 	}catch(SQLException ex) {
		 		System.out.print(ex.toString());
		 		System.out.print("error in Sending Result" + " look at SQL");
		 	}
		
		closeConnection();
		
		String DooridJson = gson.toJson(thisdoor);
		System.out.println("sending door back: "+ thisdoor);
			  
	    return  DooridJson;		
	}
	return "nothing to send back";
	}


/**
 * 
 * @param RFIDdataSent
 * @param Exists
 * 
 * 
 * @return void
 */
private void updateLogTable(RfidData RFIDdataSent,  boolean isValid){	
	try {
		// Create the INSERT statement from the parameters
		// set time inserted to be the current time on database server
		if(isValid){
			String updateSQL = 
			     	"insert into log(sensorvalue, timeinserted, dooropened) " +
			     	"values('"+RFIDdataSent.getRFIDKeyValue()+"'," +
			     	           "now()" + "," +
				 	           "1 )";
			   System.out.println("Updating log table with: " + updateSQL);
			   getConnection();
			   stmt.executeUpdate(updateSQL);
			   closeConnection();
			}else{
				String updateSQL = 
					"insert into log(sensorvalue, timeinserted, dooropened) " +
					     	"values('"+RFIDdataSent.getRFIDKeyValue()+"'," +
					     	           "now()" + "," +
						 	           "0 )";
			     System.out.println("DEBUG: Update not opened: " + updateSQL);
			     getConnection();
			     stmt.executeUpdate(updateSQL);
			     closeConnection();
			}
		
		} catch (SQLException se) {
			// Problem with update, return failure message
	    	System.out.println(se);
        	System.out.println("\nDEBUG: Update error - see error trace above for help. ");
	    	return;
		}
		// all ok,  return
		return;
	}	
}
