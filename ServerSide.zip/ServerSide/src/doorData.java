/**
 * @author Sam Robinson
 * 
 * 
 * used to create an object of door data
 * 
 */

public class doorData {

	public String doorid;
	public int motorid;
	public String clientType;
	
	public doorData(int motorid, String doorid, String clientType) {
		super();
		this.motorid = motorid;
		this.doorid = doorid; 
		this.clientType = clientType;
	}
	
	
	public void setmotorid(int motorid) {
		this.motorid= motorid;
	}
	
	public int getmotorid() {
		return motorid;
	}
	
	public void setdoorid(String doorid) {
		this.doorid = doorid;
	}	
	
	public String getdoorid() {
		return doorid;
	}
	
	public String getclientType() {
		return clientType;
	}
	public void setclientype(String clientType) {
		this.clientType = clientType;
	}

	
	
	@Override
	public String toString() {
		return "SensorData [motorid :"+ motorid +", doorid:" + doorid + ", clientType:" + clientType +"]";
	}
	

	
}
