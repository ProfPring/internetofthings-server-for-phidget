/**
 * @author Sam Robinson
 * 
 * 
 * this class is the RFID data class and is used to create an object of sensor data
 * 
 */
public class RfidData {

    public int  sensorname;
    public String RFIDKeyValue;
    public String doorid;
    public String clientType;
    public String PhoneID;

    // Constructor
    public RfidData(int sensorname, String RFIDKeyValue, String doorid, String clientType,String PhoneID) {
        super();
        this.sensorname = sensorname;
        this.RFIDKeyValue = RFIDKeyValue;
        this.doorid = doorid;
        this.clientType = clientType;
        this.PhoneID = PhoneID;
    }

    public int getSensorname() {
        return sensorname;
    }
    public void setSensorname(int sensorname) {
        this.sensorname = sensorname;
    }
    public String getRFIDKeyValue() {
        return RFIDKeyValue;
    }
    public void setRFIDKeyValue(String RFIDKeyValue) {
        this.RFIDKeyValue = RFIDKeyValue;
    }

    public String getdoorid() {
        return doorid;
    }
    public void setdoorid(String doorid) {
        this.doorid = doorid;
    }

    public String getclientType() {
        return clientType;
    }
    public void setclientype(String clientType) {
        this.clientType = clientType;
    }

    public void setPhoneID (String PhoneID){
        this.PhoneID = PhoneID;
    }
    public  String getPhoneID(){
        return PhoneID;
    }

    @Override
    public String toString() {
        return "SensorData [sensorname:" + sensorname + ", RFIDKeyValue:" + RFIDKeyValue + ", userid:" +", doorid:" + doorid + ", clientType: " + clientType + " PhoneID: " + PhoneID + "]";
    }


}

