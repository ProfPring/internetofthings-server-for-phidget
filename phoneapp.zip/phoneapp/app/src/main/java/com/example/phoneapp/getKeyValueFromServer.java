package com.example.phoneapp;

import com.google.gson.*;

public class getKeyValueFromServer {

    Gson gson = new Gson();

    SendToServer ToServer = new SendToServer();

    SensorData phoneObject =
            new SensorData (0,"unknown", "unknown", "unknown", "unknown");

    public  String GetDoorID(String IMEInumber){

        System.out.print(IMEInumber);

        phoneObject.setclientype("PhoneApp");
        phoneObject.setPhoneID(IMEInumber);

        System.out.println(IMEInumber);
        String IMEI = gson.toJson(phoneObject);

        String result = ToServer.sendToServer(IMEI);
        System.out.print(IMEI);

        phoneObject = gson.fromJson(result, SensorData.class);
        String doorid = phoneObject.getdoorid();

        System.out.println("doorid: "+ doorid);

        return doorid;
    }

    public  int getSensorName(String IMEInumber){

        System.out.print(IMEInumber);

        phoneObject.setclientype("PhoneApp");
        phoneObject.setPhoneID(IMEInumber);

        System.out.println(IMEInumber);
        String IMEI = gson.toJson(phoneObject);

        String result = ToServer.sendToServer(IMEI);
        System.out.print(IMEI);

        phoneObject = gson.fromJson(result, SensorData.class);
        int Sensorname = phoneObject.getSensorname();

        System.out.println("sensorname "+Sensorname);

        return Sensorname;
    }



}
