package com.example.phoneapp;




import android.content.Context;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import com.google.gson.*;

public class Subcriber {


    Context mContext;

    //public static final String BROKER_URL = "tcp://broker.mqttdashboard.com:1883";
    public static final String BROKER_URL = "tcp://test.mosquitto.org:1883";

    private MqttClient mqttClient;
    public Subcriber(Context mContext){

        this.mContext = mContext;
        try {
            String clientId = "phone" + "-sub";


            mqttClient = new MqttClient(BROKER_URL, clientId, null);

        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void start(String doorid, int sensorname) {
        try {

            mqttClient.setCallback(new SubcriberCallBack(mContext));
            mqttClient.connect();


            // Name of topic for subscribing.
            // NB Only works when 3rd party is publishing to this topic
            final String topic1 = doorid+"/motor";
            final String topic2 = sensorname+"/attempts";
            mqttClient.subscribe(topic1);
            mqttClient.subscribe(topic2);


            System.out.println("Subscriber is now listening to "+topic1);

            System.out.println("Subscriber is now listening to "+topic2);

        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
