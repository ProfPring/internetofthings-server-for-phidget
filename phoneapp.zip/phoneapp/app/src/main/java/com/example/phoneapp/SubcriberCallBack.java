package com.example.phoneapp;

import android.content.Context;

import org.eclipse.paho.client.mqttv3.*;

public class SubcriberCallBack implements MqttCallback {

    public static final String userid = "1";
    Context mContext;
    NotificationHelper notificationHelper;

    public SubcriberCallBack(Context mContext){
        this.mContext = mContext;
        notificationHelper= new NotificationHelper(mContext);
    }

    @Override
    public void connectionLost(Throwable cause) {
        //This is called when the connection is lost. We could reconnect here.
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        System.out.println("Message arrived. Topic: " + topic + "  Message: " + message.toString());

         notificationHelper.createNotification("MMU Hotel", message.toString());

        if ((userid+"/LWT").equals(topic)) {
            System.err.println("Sensor gone!");
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
        //no-op
    }




}