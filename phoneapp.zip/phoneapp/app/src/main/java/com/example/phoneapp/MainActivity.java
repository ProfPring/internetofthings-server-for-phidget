package com.example.phoneapp;


import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;



import org.eclipse.paho.client.mqttv3.MqttException;


public class MainActivity extends AppCompatActivity {

    private Button openDoorbtn;

    publisher publisher = new publisher();

    TextView dooridTextView;

    ImageView doorLockedUnLocked;

    Subcriber subcriber;

    NotificationHelper notificationHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //classes used
        notificationHelper= new NotificationHelper(this);
        final getKeyValueFromServer getKeyValueFromServer = new getKeyValueFromServer();

        //lay out elements
        dooridTextView = (TextView) findViewById(R.id.doornumber);
        openDoorbtn = (Button) findViewById(R.id.openDoorButton);
        doorLockedUnLocked = (ImageView) findViewById(R.id.DoorImagView);

        subcriber = new Subcriber(getApplicationContext());

        new AsyncGetRoomNumer().execute();

        openDoorbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    runOnUiThread(new Runnable() {
                                public void run() {
                                    //phone Imei Number
                                    final String phoneImeiNumber = "1503";

                                    String doorid = getKeyValueFromServer.GetDoorID(phoneImeiNumber);

                                    try {
                                        publisher.publishMotor(doorid);
                                    } catch (MqttException e) {
                                        e.printStackTrace();
                                    }


                                    new CountDownTimer(5000, 100) {

                                        public void onTick(long millisUntilFinished) {
                                            doorLockedUnLocked.setImageResource(R.drawable.unlocked);
                                            openDoorbtn.setText("door opened");
                                        }

                                        public void onFinish() {
                                            doorLockedUnLocked.setImageResource(R.drawable.locked);
                                            openDoorbtn.setText("open door");
                                        }
                                    }.start();


                                    System.out.println("publishing door id");
                            }
                        });
                    }
                });
            }

    private void ShowToast(String Text) {
        Toast.makeText(MainActivity.this, Text, Toast.LENGTH_SHORT).show();
    }


    class AsyncGetRoomNumer extends AsyncTask<String, Void, String> {
        final String phoneImeiNumber = "1503";
        final getKeyValueFromServer getKeyValueFromServer = new getKeyValueFromServer();
        @Override
        protected String doInBackground(String... strings) {

            String doorid = getKeyValueFromServer.GetDoorID(phoneImeiNumber);
            int sensoranme = getKeyValueFromServer.getSensorName(phoneImeiNumber);
            dooridTextView.setText("room number: "+doorid.toString());
            subcriber.start(doorid,sensoranme);
            return doorid;
        }
    }
}
