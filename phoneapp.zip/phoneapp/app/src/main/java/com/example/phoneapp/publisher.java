package com.example.phoneapp;

import org.eclipse.paho.client.mqttv3.*;

public class publisher {

    //public static final String BROKER_URL = "tcp://iot.eclipse.org:1883";
    //public static final String BROKER_URL = "tcp://broker.mqttdashboard.com:1883";
    public static final String BROKER_URL = "tcp://test.mosquitto.org:1883";
    public static final String userid = "1604023811"; // change this to be your student-id

    private MqttClient client;

    public publisher() {
        try {
            client = new MqttClient(BROKER_URL, userid, null);

            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(false);
            options.setMaxInflight(1000);
            options.setAutomaticReconnect(true);
            //options.notifyAll();
            options.setWill(client.getTopic(userid + "/LWT"), "I'm gone :(".getBytes(), 0, false);
            try {
                client.connect(options);
                System.out.println("publisher ready!");
                //publish out once so the door opens and closes once.
            } catch (MqttException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }


        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }


    public void publishMotor(String DoorId) throws MqttException {
        final MqttTopic MotorTopic = client.getTopic(DoorId+"/motor");
        final String motor = "door opened from phone app" + "";

        MotorTopic.publish(new MqttMessage(motor.getBytes()));
        System.out.println("Published data. Topic: " + MotorTopic.getName() + "   Message: " + motor);
    }
}
